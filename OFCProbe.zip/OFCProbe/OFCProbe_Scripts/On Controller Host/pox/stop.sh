#/bin/bash
#killall -9 screen
sudo killall -9 python2.7
