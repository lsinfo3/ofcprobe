#/bin/bash
#killall -9 screen
sudo killall -9 java
