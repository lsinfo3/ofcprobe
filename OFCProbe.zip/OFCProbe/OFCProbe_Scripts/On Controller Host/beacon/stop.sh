#/bin/bash
#killall -9 screen
killall -9 beacon
