#/bin/bash!
cd /home/openflow/controller/beacon-1.0.2/
screen -AmdS beacon bash -c './beacon configuration configurationSwitch'
