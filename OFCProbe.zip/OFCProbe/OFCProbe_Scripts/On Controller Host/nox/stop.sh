sudo killall lt-nox_core
