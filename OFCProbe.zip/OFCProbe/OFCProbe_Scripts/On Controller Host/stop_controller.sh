#/bin/bash!
cd /home/openflow/controller/remote/flood/
./stop.sh
cd /home/openflow/controller/remote/nox/
./stop.sh
cd /home/openflow/controller/remote/beacon/
./stop.sh
cd /home/openflow/controller/remote/pox/
./stop.sh
